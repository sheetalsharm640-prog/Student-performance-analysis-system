
clc;
clear;
close all;

% STUDENT PERFORMANCE ANALYSIS USING MATLAB

% Step 1: Student marks in 5 subjects
% Columns: English, Maths, Physics, Chemistry, Computer

marks = [
    78 85 90 82 88;
    65 70 68 72 75;
    88 92 85 90 94;
    55 60 58 62 65;
    72 75 78 70 80;
    90 95 92 94 96;
    60 65 62 68 70;
    82 88 85 86 90;
    75 78 72 80 82;
    68 72 70 75 78
];

% Student attendance percentage
attendance = [95 80 98 65 85 99 70 92 88 78];

% Step 2: Calculate total and average marks
totalMarks = sum(marks, 2);
averageMarks = mean(marks, 2);

fprintf('\nSTUDENT PERFORMANCE ANALYSIS\n');

disp('Total Marks of Students:');
disp(totalMarks);

disp('Average Marks of Students:');
disp(averageMarks);

% Step 3: Statistical calculations
fprintf('\nSTATISTICAL ANALYSIS\n');

allMarks = marks(:);

MeanValue = mean(allMarks);
MedianValue = median(allMarks);
ModeValue = mode(allMarks);
RangeValue = range(allMarks);
VarianceValue = var(allMarks);
StdDeviation = std(allMarks);

fprintf('Mean = %.2f\n', MeanValue);
fprintf('Median = %.2f\n', MedianValue);
fprintf('Mode = %.2f\n', ModeValue);
fprintf('Range = %.2f\n', RangeValue);
fprintf('Variance = %.2f\n', VarianceValue);
fprintf('Standard Deviation = %.2f\n', StdDeviation);

% Step 4: Correlation between attendance and marks
[r, p] = corrcoef(attendance, averageMarks);

correlation = r(1,2);

fprintf('\nCORRELATION ANALYSIS\n');
fprintf('Correlation Coefficient = %.4f\n', correlation);

% Step 5: Linear Regression
% Model: Marks = m*Attendance + c

coefficients = polyfit(attendance, averageMarks, 1);

m = coefficients(1);
c = coefficients(2);

predictedMarks = polyval(coefficients, attendance);

fprintf('\nLINEAR REGRESSION\n');
fprintf('Regression Equation: Marks = %.2f * Attendance + %.2f\n', m, c);

% Predict marks for a new attendance value
newAttendance = 90;
newPrediction = polyval(coefficients, newAttendance);

fprintf('Predicted marks at 90%% attendance = %.2f\n', newPrediction);

% Step 6: Divide students into two groups
group1 = averageMarks(1:5);
group2 = averageMarks(6:10);

[h, pValue] = ttest2(group1, group2);

fprintf('\nT-TEST ANALYSIS\n');
fprintf('Group 1 Mean = %.2f\n', mean(group1));
fprintf('Group 2 Mean = %.2f\n', mean(group2));
fprintf('P-value = %.4f\n', pValue);

if h == 1
    fprintf('There is a significant difference between groups.\n');
else
    fprintf('There is no significant difference between groups.\n');
end

% Step 7: Generate Graphs

% Graph 1: Average marks of students
figure;
bar(averageMarks);
title('Average Marks of Students');
xlabel('Student Number');
ylabel('Average Marks');
grid on;

% Graph 2: Attendance vs Marks
figure;
scatter(attendance, averageMarks, 'filled');
hold on;
plot(attendance, predictedMarks, 'r-', 'LineWidth', 2);
title('Attendance vs Examination Marks');
xlabel('Attendance (%)');
ylabel('Average Marks');
legend('Actual Marks', 'Regression Line');
grid on;
hold off;

% Graph 3: Comparison of two groups
figure;
boxplot([group1, group2], ...
    'Labels', {'Group 1', 'Group 2'});
title('Performance Comparison of Groups');
ylabel('Average Marks');
grid on;

% Step 8: Performance Report
fprintf('\nSTUDENT PERFORMANCE REPORT\n');

for i = 1:length(averageMarks)

    fprintf('Student %d: Average = %.2f, Attendance = %.2f%% - ', ...
        i, averageMarks(i), attendance(i));

    if averageMarks(i) >= 80
        fprintf('Excellent\n');
    elseif averageMarks(i) >= 60
        fprintf('Good\n');
    elseif averageMarks(i) >= 40
        fprintf('Average\n');
    else
        fprintf('Needs Improvement\n');
    end

end

fprintf('\nPROJECT COMPLETED SUCCESSFULLY!\n');
